import 'package:flutter/material.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final List<Map<String, String>> firstMenuItems = [
    {'image': 'assets/images/deal1.jpeg'},
    {'image': 'assets/images/deal2.jpeg'},
    {'image': 'assets/images/deal3.jpeg'},
    {'image': 'assets/images/deal4.jpeg'},
    {'image': 'assets/images/deal5.jpeg'},
    {'image': 'assets/images/deal6.jpeg'},
    {'image': 'assets/images/deal7.jpeg'},
    {'image': 'assets/images/deal8.jpeg'},
    {'image': 'assets/images/deal9.jpeg'},
    {'image': 'assets/images/deal10.jpeg'},
  ];

  final List<Map<String, dynamic>> categories = [
    {
      'name': 'Pizza',
      'image': 'assets/images/image1.jpeg',
      'category': 'Pizza',
    },
    {
      'name': 'Burger',
      'image': 'assets/images/image2.jpeg',
      'category': 'Burger',
    },
    {
      'name': 'Fries',
      'image': 'assets/images/image17.jpeg',
      'category': 'Snacks',
    },
    {
      'name': 'Drinks',
      'image': 'assets/images/image18.jpeg',
      'category': 'Beverage',
    },
    {
      'name': 'Chinese',
      'image': 'assets/images/image3.jpeg',
      'category': 'Chinese',
    },
    {
      'name': 'Salad',
      'image': 'assets/images/image4.jpeg',
      'category': 'Salad',
    },
    {
      'name': 'Coffee',
      'image': 'assets/images/image6.jpeg',
      'category': 'Beverage',
    },
    {
      'name': 'Sandwich',
      'image': 'assets/images/image8.jpeg',
      'category': 'Sandwich',
    },
    {
      'name': 'Dessert',
      'image': 'assets/images/image9.jpeg',
      'category': 'Dessert',
    },
    {'name': 'Desi', 'image': 'assets/images/image23.jpeg', 'category': 'Desi'},
    {
      'name': 'Main Course',
      'image': 'assets/images/image19.jpeg',
      'category': 'Main Course',
    },

    {
      'name': 'Breakfast',
      'image': 'assets/images/image13.jpeg',
      'category': 'Breakfast',
    },
  ];

  final List<Map<String, dynamic>> allFoodItems = [
    {
      'name': 'Pizza',
      'image': 'assets/images/image1.jpeg',
      'price': 950,
      'category': 'Pizza',
    },
    {
      'name': 'Burger',
      'image': 'assets/images/image2.jpeg',
      'price': 600,
      'category': 'Burger',
    },
    {
      'name': 'Pepperoni Pizza',
      'image': 'assets/images/image14.jpeg',
      'price': 900,
      'category': 'Pizza',
    },
    {
      'name': 'French Fries',
      'image': 'assets/images/image17.jpeg',
      'price': 280,
      'category': 'Snacks',
    },
    {
      'name': 'Fish and Chips',
      'image': 'assets/images/image25.jpeg',
      'price': 1200,
      'category': 'Main Course',
    },
    {
      'name': 'Mac and Cheese',
      'image': 'assets/images/image26.jpeg',
      'price': 700,
      'category': 'Main Course',
    },
    {
      'name': 'Tacos',
      'image': 'assets/images/image10.jpeg',
      'price': 500,
      'category': 'Snacks',
    },
    {
      'name': 'Burritos',
      'image': 'assets/images/image22.jpeg',
      'price': 600,
      'category': 'Snacks',
    },
    {
      'name': 'Chicken Wings',
      'image': 'assets/images/image11.jpeg',
      'price': 700,
      'category': 'Snacks',
    },
    {
      'name': 'Caesar Salad',
      'image': 'assets/images/image4.jpeg',
      'price': 600,
      'category': 'Salad',
    },
    {
      'name': 'Green Salad',
      'image': 'assets/images/image5.jpeg',
      'price': 500,
      'category': 'Salad',
    },
    {
      'name': 'Chicken Salad',
      'image': 'assets/images/image15.jpeg',
      'price': 550,
      'category': 'Salad',
    },
    {
      'name': 'Fruit Salad',
      'image': 'assets/images/image16.jpeg',
      'price': 400,
      'category': 'Salad',
    },
    {
      'name': 'Chocolate Cake',
      'image': 'assets/images/image9.jpeg',
      'price': 300,
      'category': 'Dessert',
    },
    {
      'name': 'Ice Cream Cone',
      'image': 'assets/images/image21.jpeg',
      'price': 150,
      'category': 'Dessert',
    },
    {
      'name': 'Brownie',
      'image': 'assets/images/image28.jpeg',
      'price': 250,
      'category': 'Dessert',
    },
    {
      'name': 'Strawberry Cheesecake',
      'image': 'assets/images/image30.jpeg',
      'price': 350,
      'category': 'Dessert',
    },
    {
      'name': 'Pancakes with Blueberries',
      'image': 'assets/images/image13.jpeg',
      'price': 400,
      'category': 'Breakfast',
    },
    {
      'name': 'Iced Coffee',
      'image': 'assets/images/image6.jpeg',
      'price': 300,
      'category': 'Beverage',
    },
    {
      'name': 'Strawberry Smoothie',
      'image': 'assets/images/image7.jpeg',
      'price': 350,
      'category': 'Beverage',
    },
    {
      'name': 'Mango Juice',
      'image': 'assets/images/image12.jpeg',
      'price': 250,
      'category': 'Beverage',
    },
    {
      'name': 'Lemon Mojito',
      'image': 'assets/images/image18.jpeg',
      'price': 400,
      'category': 'Beverage',
    },
    {
      'name': 'Steak with Rice',
      'image': 'assets/images/image19.jpeg',
      'price': 1200,
      'category': 'Main Course',
    },
    {
      'name': 'Cappuccino',
      'image': 'assets/images/image20.jpeg',
      'price': 350,
      'category': 'Beverage',
    },
    {
      'name': 'Bubble Tea',
      'image': 'assets/images/image24.jpeg',
      'price': 450,
      'category': 'Beverage',
    },
    {
      'name': 'Orange Juice',
      'image': 'assets/images/image27.jpeg',
      'price': 200,
      'category': 'Beverage',
    },
    {
      'name': 'Sushi Platter',
      'image': 'assets/images/image3.jpeg',
      'price': 1200,
      'category': 'Chinese',
    },
    {
      'name': 'Sushi Bento Box',
      'image': 'assets/images/image29.jpeg',
      'price': 1000,
      'category': 'Chinese',
    },
    {
      'name': 'Grilled Sandwich',
      'image': 'assets/images/image8.jpeg',
      'price': 500,
      'category': 'Sandwich',
    },
    {
      'name': 'Korean Hotpot',
      'image': 'assets/images/image23.jpeg',
      'price': 1500,
      'category': 'Main Course',
    },
    {
      'name': 'Roasted Chicken with Lemon',
      'image': 'assets/images/image29.jpeg',
      'price': 800,
      'category': 'Main Course',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: Row(
          children: [
            Image.asset('assets/images/logor.jpg', width: 50, height: 50),
            SizedBox(width: 10),
            Text(
              'Bite Buddy',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.red[800],
              ),
            ),
            Spacer(),
            CircleAvatar(
              backgroundColor: Colors.red,
              child: IconButton(
                icon: Icon(Icons.person, color: Colors.white),
                onPressed: () {
                  // Handle user profile action
                },
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHorizontalList(
              firstMenuItems,
              false,
            ), // First menu (Images only)
            _buildBannerImage(),
            _buildHorizontalList(
              categories,
              true,
            ), // Second menu (Category pop-ups)
            _buildScrollableSection("Customer Ratings"),
            _buildScrollableSection("Comments"),
          ],
        ),
      ),
    );
  }

  Widget _buildHorizontalList(
    List<Map<String, dynamic>> menuItems,
    bool isCategoryMenu,
  ) {
    return SizedBox(
      height: 140, // Reduced height
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: menuItems.length,
        itemBuilder: (context, index) {
          return _buildFoodCard(menuItems[index], isCategoryMenu);
        },
      ),
    );
  }

  Widget _buildFoodCard(Map<String, dynamic> item, bool isCategoryMenu) {
    return GestureDetector(
      onTap: () {
        if (isCategoryMenu) {
          _filterAndShowCategory(
            item['name'],
          ); // Second menu shows category list
        }
      },
      child: Container(
        width: 120, // Reduced width
        margin: EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Colors.grey[800], // Grey background
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 3,
              blurRadius: 6,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.all(8.0), // Padding to prevent image overflow
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              item['image'],
              height: 80, // Reduced image size
              width: 100,
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }

  void _filterAndShowCategory(String category) {
    List<Map<String, dynamic>> filteredItems =
        allFoodItems
            .where((foodItem) => foodItem['category'] == category)
            .toList();

    _showFoodPopup(category, filteredItems);
  }

  void _showFoodPopup(
    String category,
    List<Map<String, dynamic>> filteredItems,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.black,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          height: MediaQuery.of(context).size.height * 0.75,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  icon: Icon(Icons.close, color: Colors.white, size: 28),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              Text(
                "Available $category Options",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Expanded(
                child: ListView.builder(
                  itemCount: filteredItems.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Image.asset(
                        filteredItems[index]['image'],
                        width: 60,
                        height: 60,
                      ),
                      title: Text(
                        filteredItems[index]['name'],
                        style: TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        "Delicious and fresh",
                        style: TextStyle(color: Colors.white70),
                      ),
                      trailing: Text(
                        "\$${filteredItems[index]['price']}",
                        style: TextStyle(color: Colors.red),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBannerImage() {
    return Image.asset(
      'assets/images/logo.jpg',
      width: double.infinity,
      height: 500,
      fit: BoxFit.cover,
    );
  }

  Widget _buildScrollableSection(String title) {
    return SizedBox(
      height: 200,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              title,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: 5,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: AssetImage(
                      'assets/images/user$index.jpeg',
                    ),
                  ),
                  title: Text(
                    "User   $index",
                    style: TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    "⭐⭐⭐⭐⭐ Excellent!",
                    style: TextStyle(color: Colors.white),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
