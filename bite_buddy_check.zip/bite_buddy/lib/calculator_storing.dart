
void main() {}

class store_Chicken_Tikka_Pizza {
  // double? pizzaDough = 0;
  // double? pizzaSauce = 0;
  // double? mozzarellaCheese = 0;
  // double? Onions = 0;
  // double? Capsicum = 0;
  // double? spicyChickenTikkaChunks = 0;
  // double? greenChilies = 0;
  // double? oreganoItalianHerbs = 0;
  double pizza_crust_calories_per_gram = 3.31;
  double Chicken_Tikka_Pizza_style_sauce_calories_per_gram = 6;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double onions_calories_per_gram = 0.25;
  double bbq_chicken_calories_per_gram = 1.80;
  double green_chilies_calories_per_gram = 0.4;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? spicychickenTikkachunks,
    double? greenChilies,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Chicken_Tikka_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (spicychickenTikkachunks != null) {
      result += spicychickenTikkachunks * bbq_chicken_calories_per_gram;
    }
    if (greenChilies != null) {
      result += greenChilies * green_chilies_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }

    return result;
  }

  //  store_Chicken_Tikka_Pizza? obj;

  //       obj!.pizzaDough = double.tryParse(
  //         _quantityControllers["Pizza Dough"]!.text);
  //       obj!.pizzaSauce = double.tryParse(
  //         _quantityControllers["Pizza Sauce"]!.text);
  //       obj!.mozzarellaCheese = double.tryParse(
  //         _quantityControllers["Mozzarella Cheese"]!.text);
  //        obj!.Onions = double.tryParse(
  //         _quantityControllers["Onions"]!.text);
  //         obj!.Capsicum = double.tryParse(
  //         _quantityControllers["Capsicum"]!.text);
  //         obj!.spicyChickenTikkaChunks = double.tryParse(
  //         _quantityControllers["Spicy Chicken Tikka Chunks"]!.text);
  //         obj!.greenChilies = double.tryParse(
  //         _quantityControllers["Green Chilies"]!.text);
  //         obj!.oreganoItalianHerbs=double.tryParse(
  //         _quantityControllers["Oregano Herbs"]!.text);
}

class store_Fajita_Pizza {
  // double? pizzaDough = 0;
  // double? pizzaSauce = 0;
  // double? mozzarellaCheese = 0;
  // double? Onions = 0;
  // double? Capsicum = 0;
  // double? fajitaStyleGrilledChicken = 0;
  // double? Jalapenos = 0;
  // double? oreganoItalianHerbs = 0;

  double pizza_crust_calories_per_gram = 3.31;
  double Fajita_Pizza_style_sauce_calories_per_gram = 2;
  double fajita_chicken_calories_per_gram = 1.75;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double onions_calories_per_gram = 0.25;
  double jalapenos_calories_per_gram = 0.40;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? fajitaStyleGrilledChicken,
    double? Jalapenos,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result += pizzaSauce * (Fajita_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (fajitaStyleGrilledChicken != null) {
      result += fajitaStyleGrilledChicken * fajita_chicken_calories_per_gram;
    }
    if (Jalapenos != null) {
      result += Jalapenos * jalapenos_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }

    return result;
  }
}

class Pepperoni_Pizza {
  double pizza_crust_calories_per_gram = 3.31;
  double Pepperoni_Pizza_style_sauce_calories_per_gram = 2;
  double pepperoni_calories_per_gram = 4.94;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double onions_calories_per_gram = 0.25;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? beefPepperoniSlices,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Pepperoni_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (beefPepperoniSlices != null) {
      result += beefPepperoniSlices * pepperoni_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Chicken_Supreme_Pizza {
  double pizza_crust_calories_per_gram = 3.31;
  double Chicken_Supreme_style_sauce_calories_per_gram = 2;
  double extraChickenChunks_calories_per_gram = 2;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double mushrooms_calories_per_gram = 0.22;
  double onions_calories_per_gram = 0.25;
  double black_olives_calories_per_gram = 1.15;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? extraChickenChunks,
    double? Mushrooms,
    double? blackOlive,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Chicken_Supreme_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (extraChickenChunks != null) {
      result += extraChickenChunks * extraChickenChunks_calories_per_gram;
    }
    if (Mushrooms != null) {
      result += Mushrooms * mushrooms_calories_per_gram;
    }
    if (blackOlive != null) {
      result += blackOlive * black_olives_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Afghani_Tikka_Pizza {
  double pizza_crust_calories_per_gram = 3.31;
  double Afghani_Creamy_tikka_sauce_calories_per_gram = 3;
  double afghani_chicken_calories_per_gram = 2.00;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double onions_calories_per_gram = 0.25;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? creamyAfghaniTikkaChicken,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * pizza_crust_calories_per_gram;
    }
    if (pizzaSauce != null) {
      result += pizzaSauce * Afghani_Creamy_tikka_sauce_calories_per_gram;
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (creamyAfghaniTikkaChicken != null) {
      result += creamyAfghaniTikkaChicken * afghani_chicken_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Veggie_Lovers_Pizza {
  double pizza_crust_calories_per_gram = 3.31;
  double Veggie_Lovers_Pizza_style_sauce_calories_per_gram = 1;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double mushrooms_calories_per_gram = 0.22;
  double onions_calories_per_gram = 0.25;
  double black_olives_calories_per_gram = 1.15;
  double Tomatoes_calories_per_gram = 0.18;
  double Jalapenos_calories_per_gram = 0.40;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? Mushrooms,
    double? blackOlives,
    double? Tomatoes,
    double? Jalapenos,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Veggie_Lovers_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (Tomatoes != null) {
      result += Tomatoes * Tomatoes_calories_per_gram;
    }
    if (Mushrooms != null) {
      result += Mushrooms * mushrooms_calories_per_gram;
    }
    if (blackOlives != null) {
      result += blackOlives * black_olives_calories_per_gram;
    }
    if (Jalapenos != null) {
      result += Jalapenos * Jalapenos_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Cheese_Lovers_Pizza {
  double pizza_crust_calories_per_gram = 3.31;
  double Cheese_Lovers_Pizza_style_sauce_calories_per_gram = 2.5;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double cheddar_cheese_calories_per_gram = 4.03;
  double parmesan_Cheese_calories_per_gram = 4.03;
  double blue_Cheese_calories_per_gram = 4;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? cheddarCheese,
    double? parmesanCheese,
    double? blueCheese,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Cheese_Lovers_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (cheddarCheese != null) {
      result += cheddarCheese * cheddar_cheese_calories_per_gram;
    }
    if (parmesanCheese != null) {
      result += parmesanCheese * parmesan_Cheese_calories_per_gram;
    }
    if (blueCheese != null) {
      result += blueCheese * blue_Cheese_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Crown_Crust_Pizza {
  // double? pizzaDough = 0;
  // double? pizzaSauce = 0;
  // double? mozzarellaCheese = 0;
  // double? chickenNuggetsOrCheesePocketsInCrust = 0;
  // double? chickenTikkaChunksOrBbqChicken = 0;
  // double? beefPepperoniSlices = 0;
  // double? Onions = 0;
  // double? Capsicum = 0;
  // double? blackOlives = 0;
  // double? Tomatoes = 0;
  // double? Jalapenos = 0;
  // double? oreganoItalianHerbs = 0;

  double pizza_crust_calories_per_gram = 3.31;
  double Crown_Crust_Pizza_style_sauce_calories_per_gram = 1.8;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double chickenNuggetsOrCheesePocketsInCrust_calories_per_gram = 3.2;
  //double? chickenTikkaChunksOrBbqChicken
  double chickenTikkaChunksOrBbqChicken_calories_per_gram = 1.80;
  double pepperoni_calories_per_gram = 4.94;
  double onions_calories_per_gram = 0.25;
  double black_olives_calories_per_gram = 1.15;
  double Tomatoes_calories_per_gram = 0.18;
  double Jalapenos_calories_per_gram = 0.40;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? chickenNuggetsOrCheesePocketsInCrust,
    double? chickenTikkaChunksOrBbqChicken,
    double? beefPepperoniSlices,
    double? Onions,
    double? Capsicum,
    double? blackOlives,
    double? Tomatoes,
    double? Jalapenos,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Crown_Crust_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (chickenNuggetsOrCheesePocketsInCrust != null) {
      result +=
          chickenNuggetsOrCheesePocketsInCrust *
          chickenNuggetsOrCheesePocketsInCrust_calories_per_gram;
    }
    if (chickenTikkaChunksOrBbqChicken != null) {
      result +=
          chickenTikkaChunksOrBbqChicken *
          chickenTikkaChunksOrBbqChicken_calories_per_gram;
    }
    if (beefPepperoniSlices != null) {
      result += beefPepperoniSlices * pepperoni_calories_per_gram;
    }
    if (Onions != null) {
      result += Onions * onions_calories_per_gram;
    }
    if (Capsicum != null) {
      result += Capsicum * capsicum_calories_per_gram;
    }
    if (Tomatoes != null) {
      result += Tomatoes * Tomatoes_calories_per_gram;
    }
    if (blackOlives != null) {
      result += blackOlives * black_olives_calories_per_gram;
    }
    if (Jalapenos != null) {
      result += Jalapenos * Jalapenos_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Behari_Kebab_Pizza {
  double? pizzaDough = 0;
  int? pizzaSauce = 0;
  double? mozzarellaCheese = 0;
  double? Onions = 0;
  double? Capsicum = 0;
  double? behariSpicedBeefKebabPieces = 0;
  double? greenChilies = 0;
  double? oreganoItalianHerbs = 0;

  double pizza_crust_calories_per_gram = 3.31;
  double Pepperoni_Pizza_style_sauce_calories_per_gram = 2.5;
  double behariSpicedBeefKebabPieces_calories_per_gram = 3.2;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double green_chilies_calories_per_gram = 0.4;
  double onions_calories_per_gram = 0.25;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? behariSpicedBeefKebabPieces,
    double? greenChilies,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (pizzaSauce != null) {
      result +=
          pizzaSauce * (Pepperoni_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (behariSpicedBeefKebabPieces != null) {
      result +=
          behariSpicedBeefKebabPieces *
          behariSpicedBeefKebabPieces_calories_per_gram;
    }
    if (greenChilies != null) {
      result += greenChilies * green_chilies_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class Creamy_Super_Max_Pizza {
  // double? pizzaDough = 0;
  // double? whiteOrCreamySauce = 0;
  // double? mozzarellaCheese = 0;
  // double? Onions = 0;
  // double? Capsicum = 0;
  // double? chickenChunks = 0;
  // double? sweetCorn = 0;
  // double? oreganoItalianHerbs = 0;

  double pizza_crust_calories_per_gram = 3.31;
  double Creamy_Super_Max_Pizza_style_sauce_calories_per_gram = 4;
  double chickenChunks_calories_per_gram = 2.5;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double sweetCorn_calories_per_gram = 1;
  double onions_calories_per_gram = 0.25;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? whiteOrCreamySauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? chickenChunks,
    double? sweetCorn,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram ?? 0);
    }
    if (whiteOrCreamySauce != null) {
      result +=
          whiteOrCreamySauce *
          (Creamy_Super_Max_Pizza_style_sauce_calories_per_gram ?? 0);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (chickenChunks != null) {
      result += chickenChunks * chickenChunks_calories_per_gram;
    }
    if (sweetCorn != null) {
      result += sweetCorn * sweetCorn_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}

class BBQ_Chicken_Pizza {
  // double? pizzaDough = 0;
  // double? pizzaOrBbqSauce = 0;
  // double? mozzarellaCheese = 0;
  // double? Onions = 0;
  // double? Capsicum = 0;
  // double? smokedBbqChickenPieces = 0;
  // double? oreganoItalianHerbs = 0;

  double pizza_crust_calories_per_gram = 3.31;
  double BBQ_Chicken_Pizza_style_sauce_calories_per_gram = 2.5;
  double BbqChickenPieces_calories_per_gram = 2;
  double mozzarella_cheese_calories_per_gram = 2.80;
  double capsicum_calories_per_gram = 0.25;
  double onions_calories_per_gram = 0.25;
  double oregano_italianherb_calorie_per_gram = 3;

  double? calculate_calories(
    double? pizzaDough,
    double? pizzaOrBbqSauce,
    double? mozzarellaCheese,
    double? Onion,
    double? Capsicums,
    double? smokedBbqChickenPieces,
    double? oreganoItalianherbs,
  ) {
    double result = 0;

    if (pizzaDough != null) {
      result += pizzaDough * (pizza_crust_calories_per_gram);
    }
    if (pizzaOrBbqSauce != null) {
      result +=
          pizzaOrBbqSauce * (BBQ_Chicken_Pizza_style_sauce_calories_per_gram);
    }
    if (mozzarellaCheese != null) {
      result += mozzarellaCheese * mozzarella_cheese_calories_per_gram;
    }
    if (Onion != null) {
      result += Onion * onions_calories_per_gram;
    }
    if (Capsicums != null) {
      result += Capsicums * capsicum_calories_per_gram;
    }
    if (smokedBbqChickenPieces != null) {
      result += smokedBbqChickenPieces * BbqChickenPieces_calories_per_gram;
    }
    if (oreganoItalianherbs != null) {
      result += oreganoItalianherbs * oregano_italianherb_calorie_per_gram;
    }
    return result;
  }
}
