import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'SupplierScreen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _supplierNameController = TextEditingController();
  final TextEditingController _shopNameController = TextEditingController();
  final TextEditingController _contactNumberController =
      TextEditingController();
  final _formKey = GlobalKey<FormState>(); // Form key for validation

  final FirebaseAuth _auth = FirebaseAuth.instance;

  DatabaseReference ref = FirebaseDatabase.instance.ref("users");

  String? _selectedRole;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
      return 'Please enter a valid email';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }

  String? _validateContactNumber(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your contact number';
    }
    if (value.length < 10) {
      return 'Contact number must be at least 10 digits';
    }
    return null;
  }

  String? _validateSupplierName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your supplier name';
    }
    return null;
  }

  String? _validateShopName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your shop name';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF000000), // Black background
      appBar: AppBar(
        title: const Text(
          'Sign Up',
          style: TextStyle(color: Colors.white), // White text
        ),
        backgroundColor: Colors.black, // AppBar background set to black
        elevation: 0,
      ),
      body: FadeTransition(
        opacity: _animation,
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Circular Image
                  ClipOval(
                    child: Image.asset(
                      'assets/images/logor.jpg',
                      width: MediaQuery.of(context).size.width * 0.20,
                      height: MediaQuery.of(context).size.width * 0.20,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 20),

                  const Text(
                    'Create an Account',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: DropdownButtonFormField<String>(
                      value: _selectedRole,
                      items: const [
                        DropdownMenuItem(
                          value: 'Customer',
                          child: Text('Customer'),
                        ),
                        DropdownMenuItem(
                          value: 'Supplier',
                          child: Text('Supplier'),
                        ),
                      ],
                      onChanged: (value) {
                        setState(() {
                          _selectedRole = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Select Role',
                        labelStyle: const TextStyle(color: Colors.red),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        prefixIcon: const Icon(
                          Icons.person,
                          color: Colors.white,
                        ),
                      ),
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Conditional fields based on selected role
                  if (_selectedRole == 'Supplier') ...[
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      child: TextFormField(
                        controller: _supplierNameController,
                        decoration: InputDecoration(
                          labelText: 'Supplier Name',
                          labelStyle: const TextStyle(color: Colors.white),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          prefixIcon: const Icon(
                            Icons.business,
                            color: Colors.white,
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        validator: _validateSupplierName,
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      child: TextFormField(
                        controller: _shopNameController,
                        decoration: InputDecoration(
                          labelText: 'Shop Name',
                          labelStyle: const TextStyle(color: Colors.white),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          prefixIcon: const Icon(
                            Icons.store,
                            color: Colors.white,
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        validator: _validateShopName,
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      child: TextFormField(
                        controller: _contactNumberController,
                        decoration: InputDecoration(
                          labelText: 'Contact Number',
                          labelStyle: const TextStyle(color: Colors.white),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          prefixIcon: const Icon(
                            Icons.phone,
                            color: Colors.white,
                          ),
                        ),
                        style: const TextStyle(color: Colors.white),
                        validator: _validateContactNumber,
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: TextFormField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        labelStyle: const TextStyle(color: Colors.white),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        prefixIcon: const Icon(
                          Icons.email,
                          color: Colors.white,
                        ),
                      ),
                      style: const TextStyle(color: Colors.white),
                      validator: _validateEmail,
                    ),
                  ),
                  const SizedBox(height: 16),

                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: const TextStyle(color: Colors.white),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        prefixIcon: const Icon(Icons.lock, color: Colors.white),
                      ),
                      style: const TextStyle(color: Colors.white),
                      validator: _validatePassword,
                    ),
                  ),
                  const SizedBox(height: 16),

                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (_formKey.currentState!.validate()) {
                          try {
                            final UserCredential userCredential = await _auth
                                .createUserWithEmailAndPassword(
                                  email: _emailController.text.trim(),
                                  password: _passwordController.text.trim(),
                                );

                            if (userCredential.user != null) {
                              String? id =
                                  FirebaseAuth.instance.currentUser?.uid;
                              // String? id = sId?.uid;
                              if (_selectedRole == 'Supplier') {
                                Map<String, dynamic> supplierInfo = {
                                  'Supplier Name': _supplierNameController.text,
                                  'Shop Name': _shopNameController.text,
                                  'Contact Number':
                                      _contactNumberController.text,
                                  'Email': _emailController.text,
                                  'Password': _passwordController.text,
                                };
                                await ref
                                    .child("Supplier")
                                    .child(id.toString())
                                    .child("Supplier_info")
                                    .set(supplierInfo);
                              } else if (_selectedRole == 'Customer') {
                                Map<String, dynamic> customerInfo = {
                                  'Email': _emailController.text,
                                  'Password': _passwordController.text,
                                };
                                await ref
                                    .child("Customer")
                                    .child(id.toString())
                                    .child("Customer_info")
                                    .set(customerInfo);
                              }
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Signup successful!'),
                                ),
                              );
                              if (_selectedRole == 'Supplier') {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder:
                                        (context) => const SupplierScreen(),
                                  ),
                                );
                              }
                              Navigator.pop(context, true);
                            }
                          } on FirebaseAuthException catch (e) {
                            String message = 'An error occurred during signup';
                            if (e.code == 'weak-password') {
                              message = 'The password provided is too weak.';
                            } else if (e.code == 'email-already-in-use') {
                              message =
                                  'An account already exists for that email.';
                            } else if (e.code == 'invalid-email') {
                              message = 'Please enter a valid email address.';
                            }
                            ScaffoldMessenger.of(
                              context,
                            ).showSnackBar(SnackBar(content: Text(message)));
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(e.toString())),
                            );
                          }
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFDD050D),
                        padding: const EdgeInsets.symmetric(vertical: 16.0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      child: const Text(
                        'Sign Up',
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
