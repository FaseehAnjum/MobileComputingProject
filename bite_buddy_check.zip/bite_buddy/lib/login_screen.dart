import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'signup_screen.dart'; // Import the SignupScreen
import 'SupplierScreen.dart'; // Import the SupplierScreen
import 'package:firebase_database/firebase_database.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>(); // Form key for validation
  DatabaseReference ref = FirebaseDatabase.instance.ref("users");

  String? _selectedRole = 'User  '; // Default role

  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // Email validation
  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
      return 'Please enter a valid email';
    }
    return null;
  }

  // Password validation
  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }

  void _login() async {
    if (_formKey.currentState!.validate()) {
      try {
        final UserCredential userCredential = await _auth
            .signInWithEmailAndPassword(
              email: _emailController.text.trim(),
              password: _passwordController.text.trim(),
            );

        final user = userCredential.user;
        if (user != null) {
          String uid = user.uid;
          String selectedRole =
              _selectedRole!.trim(); // 'Customer' or 'Supplier'
          print("Login UID: $uid");
          print("Selected Role: $selectedRole");

          final rolePath = selectedRole == 'Supplier' ? 'Supplier' : 'Customer';
          final infoPath =
              selectedRole == 'Supplier' ? 'Supplier_info' : 'Customer_info';

          // Check if the user exists in the database
          final snapshot =
              await ref.child(rolePath).child(uid).child(infoPath).get();

          if (snapshot.exists && snapshot.value != null) {
            // Data found
            ScaffoldMessenger.of(
              context,
            ).showSnackBar(const SnackBar(content: Text('Login successful!')));

            if (selectedRole == 'Supplier') {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const SupplierScreen()),
              );
            } else {
              Navigator.pop(context, true);
            }
          } else {
            // User exists in Firebase Auth but not in the database for the selected role
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('No user found in $selectedRole role.')),
            );
          }
        }
      } on FirebaseAuthException catch (e) {
        // Handle specific FirebaseAuth exceptions
        if (e.code == 'user-not-found') {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No user found for that email.')),
          );
        } else if (e.code == 'wrong-password') {
          // Check if the user exists in the database for the selected role
          final user = _auth.currentUser;
          if (user != null) {
            String uid = user.uid;
            String selectedRole =
                _selectedRole!.trim(); // 'Customer' or 'Supplier'
            final rolePath =
                selectedRole == 'Supplier' ? 'Supplier' : 'Customer';
            final infoPath =
                selectedRole == 'Supplier' ? 'Supplier_info' : 'Customer_info';

            // Check if the user exists in the database
            final snapshot =
                await ref.child(rolePath).child(uid).child(infoPath).get();

            if (snapshot.exists) {
              // User exists but password is incorrect
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Incorrect password. Please try again.'),
                ),
              );
            } else {
              // User does not exist in the database
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('No user found in $selectedRole role.')),
              );
            }
          }
        } else {
          // Handle other FirebaseAuth exceptions
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('An error occurred: ${e.message}')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('An unexpected error occurred: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF000000), // Same background color
      appBar: AppBar(
        title: const Text(
          'Login',
          style: TextStyle(color: Colors.white), // Fixed white text
        ),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: FadeTransition(
        opacity: _animation,
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Circular Image
                  ClipOval(
                    child: Image.asset(
                      'assets/images/logor.jpg',
                      width:
                          MediaQuery.of(context).size.width *
                          0.2, // Adjust size
                      height:
                          MediaQuery.of(context).size.width *
                          0.2, // Ensure circle
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Welcome Text (Fixed)
                  const Text(
                    'Welcome Back!',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white, // Fixed duplicate style issue
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Role Selection Dropdown
                  SizedBox(
                    width:
                        MediaQuery.of(context).size.width *
                        0.5, // Set the width to 40% of the screen width
                    child: DropdownButtonFormField<String>(
                      value: _selectedRole,
                      items: const [
                        DropdownMenuItem(
                          value: 'User  ',
                          child: Text('User  '),
                        ),
                        DropdownMenuItem(
                          value: 'Supplier',
                          child: Text('Supplier'),
                        ),
                      ],
                      onChanged: (value) {
                        setState(() {
                          _selectedRole = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Select Role',
                        labelStyle: const TextStyle(color: Colors.red),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        prefixIcon: const Icon(
                          Icons.person,
                          color: Colors.white,
                        ),
                      ),
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Email Field
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: TextFormField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        labelStyle: const TextStyle(
                          color: Colors.white,
                        ), // Text color white
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        prefixIcon: const Icon(
                          Icons.email,
                          color: Colors.white,
                        ),
                      ),
                      style: const TextStyle(
                        color: Colors.white,
                      ), // Input text color white
                      validator: _validateEmail,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Password Field
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: const TextStyle(
                          color: Colors.white,
                        ), // Text color white
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        prefixIcon: const Icon(Icons.lock, color: Colors.white),
                      ),
                      style: const TextStyle(
                        color: Colors.white,
                      ), // Input text color white
                      validator: _validatePassword,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Login Button
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16.0),
                        backgroundColor: const Color(0xFFDD050D),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      child: const Text(
                        'Login',
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Signup Link
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SignupScreen(),
                        ),
                      );
                    },
                    child: const Text(
                      'Don\'t have an account? Sign Up',
                      style: TextStyle(
                        color: Colors.white,
                      ), // Ensured white text
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
