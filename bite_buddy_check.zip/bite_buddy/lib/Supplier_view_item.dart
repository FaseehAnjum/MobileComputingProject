import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SupplierViewItem extends StatefulWidget {
  const SupplierViewItem({super.key});

  @override
  _SupplierViewItem createState() => _SupplierViewItem();
}

class _SupplierViewItem extends State<SupplierViewItem>
    with TickerProviderStateMixin {
  User? s_id = FirebaseAuth.instance.currentUser;
  final ref = FirebaseDatabase.instance.ref("users/Supplier_items");

  List<Map<dynamic, dynamic>> itemList = [];
  List<bool> flipped = [];
  List<AnimationController> controllers = [];
  List<Animation<double>> animations = [];

  void fetchItemsForSupplier() async {
    String? supplierId = s_id?.uid;
    final snapshot = await ref.child(supplierId.toString()).once();

    if (snapshot.snapshot.exists) {
      final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

      List<Map<dynamic, dynamic>> tempList = [];
      data.forEach((key, value) {
        tempList.add(value);
      });

      // Init animation controllers
      for (var c in controllers) {
        c.dispose();
      }
      controllers = List.generate(
        tempList.length,
        (index) => AnimationController(
          duration: const Duration(milliseconds: 500),
          vsync: this,
        ),
      );
      animations =
          controllers
              .map(
                (controller) =>
                    Tween<double>(begin: 0, end: 1).animate(controller),
              )
              .toList();

      setState(() {
        itemList = tempList;
        flipped = List<bool>.filled(tempList.length, false);
      });
    } else {
      setState(() {
        itemList = [];
        flipped = [];
      });
    }
  }

  void toggleCard(int index) {
    if (flipped[index]) {
      controllers[index].reverse();
    } else {
      controllers[index].forward();
    }
    setState(() {
      flipped[index] = !flipped[index];
    });
  }

  @override
  void dispose() {
    for (var controller in controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pizza Items")),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: fetchItemsForSupplier,
            child: const Text("View"),
          ),
          const SizedBox(height: 8),
          Expanded(
  child: GridView.builder(
    padding: const EdgeInsets.all(8),
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      childAspectRatio: 0.8,
    ),
    itemCount: itemList.length,
    itemBuilder: (context, index) {
      final item = itemList[index];
      final flavour = item['Flavour'] ?? 'No Flavour';

      // ✅ FIXED INGREDIENTS PARSING
      final rawIngredients = item['ingredients'] as Map?;
      final ingredientList = rawIngredients?.entries.map((entry) {
        return "${entry.key}: ${entry.value}";
      }).toList() ?? [];
      final ingredients = ingredientList.join('\n');

      return GestureDetector(
        onTap: () => toggleCard(index),
        child: AnimatedBuilder(
          animation: animations[index],
          builder: (context, child) {
            return RotationYTransition(
              turns: animations[index],
              front: _buildFrontCard(flavour, index),
              back: _buildBackCard(ingredients, index),
            );
          },
        ),
      );
    },
  ),
),
        ],
      ),
    );
  }

  Widget _buildFrontCard(String flavour, int index) {
    return Card(
      key: ValueKey("front_$index"),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(16),
              ),
              child: Image.asset(
                'assets/images/image4.jpeg',
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(8),
            alignment: Alignment.center,
            child: Text(
              flavour,
              style: const TextStyle(fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackCard(String ingredients, int index) {
    return Card(
      key: ValueKey("back_$index"),
      color: Colors.deepOrange[100],
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            "Ingredients:\n$ingredients",
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}

/// 3D flip animation along the Y axis
class RotationYTransition extends AnimatedWidget {
  final Widget front;
  final Widget back;

  const RotationYTransition({super.key, 
    required Animation<double> turns,
    required this.front,
    required this.back,
  }) : super(listenable: turns);

  @override
  Widget build(BuildContext context) {
    final animation = listenable as Animation<double>;
    final value = animation.value;
    final isBackVisible = value > 0.5;
    final display = isBackVisible ? back : front;

    return Transform(
      alignment: Alignment.center,
      transform:
          Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateY(value * 3.1416),
      child:
          isBackVisible
              ? Transform(
                alignment: Alignment.center,
                transform: Matrix4.rotationY(3.1416),
                child: display,
              )
              : display,
    );
  }
}
