import 'package:flutter/material.dart';
import 'login_and_signup_btn.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          elevation: 0,
          centerTitle: true, // Ensures center alignment on Android too
        ),
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            color: Colors.black, // Background color black
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Expanded(
                flex: 4, // Image section
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: ClipOval(
                    // Makes the logo circular
                    child: Image.asset(
                      'assets/images/logor.jpg',
                      width:
                          MediaQuery.of(context).size.width *
                          0.3, // 60% of screen width
                      height:
                          MediaQuery.of(context).size.width *
                          0.2, // Ensuring circular shape
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              Expanded(
                flex: 2, // Buttons section
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [LoginAndSignupBtn()],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
