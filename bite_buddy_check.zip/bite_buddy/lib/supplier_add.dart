//import 'dart:nativewrappers/_internal/vm/lib/developer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'calculator_storing.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';

class SupplierAdd extends StatefulWidget {
  const SupplierAdd({super.key});

  @override
  _SupplierAddState createState() => _SupplierAddState();
}

class _SupplierAddState extends State<SupplierAdd> {
  User? s_id = FirebaseAuth.instance.currentUser;
  DatabaseReference ref = FirebaseDatabase.instance.ref("users");
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final Map<String, TextEditingController> _quantityControllers = {};
  bool _showOtherTextBox = false;
  final TextEditingController _otherToppingController = TextEditingController();

  String? selectedSize;
  String? selectedFlavour;

  final List<String> pizzaSizes = ['Small', 'Medium', 'Large', 'Extra Large'];

  final List<String> pizzaFlavours = [
    'Chicken Tikka Pizza',
    'Fajita Pizza',
    'Pepperoni Pizza',
    'Chicken Supreme Pizza',
    'BBQ Chicken Pizza',
    'Creamy Super Max Pizza',
    'Behari Kebab Pizza',
    'Afghani Tikka Pizza',
    'Veggie Lovers Pizza',
    'Cheese Lovers Pizza',
    'Crown Crust Pizza',
  ];

  final Map<String, List<String>> flavourToppings = {
    'Chicken Tikka Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Spicy Chicken Tikka Chunks',
      'Green Chilies',
      'Oregano Herbs',
    ],
    'Fajita Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Fajita_style Grilled Meat',
      'Jalapenos',
      'Oregano Herbs',
    ],
    'Pepperoni Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Beef Pepperoni Slices',
      'Oregano Herbs',
    ],
    'Chicken Supreme Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Extra Chicken Chunks',
      'Mushrooms',
      'Black Olives',
      'Oregano Herbs',
    ],
    'Afghani Tikka Pizza': [
      'Pizza Dough',
      'Pizza Sauce ',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Creamy Afghani Tikka Chicken',
      'Oregano Herbs',
    ],
    'Veggie Lovers Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Mushrooms',
      'Black Olives',
      'Tomatoes',
      'Jalapenos',
      'Oregano Herbs',
    ],
    'Cheese Lovers Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Cheddar Cheese',
      'Parmesan Cheese',
      'Blue Cheese',
      'Oregano Herbs',
    ],
    'Crown Crust Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Chicken Nuggets or Cheese Pockets (in Crust)',
      'Chicken Tikka Chunks or BBQ Chicken',
      'Beef Pepperoni Slices',
      'Onions',
      'Capsicum (Bell Peppers)',
      'Black Olives',
      'Tomatoes',
      'Jalapenos (optional)',
      'Oregano Herbs',
    ],
    'Behari Kebab Pizza': [
      'Pizza Dough',
      'Pizza Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Behari_Spiced Beef Kebab Pieces',
      'Green Chilies',
      'Oregano Herbs',
    ],
    'Creamy Super Max Pizza': [
      'Pizza Dough',
      'White_Creamy Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Chicken Chunks',
      'Sweet Corn',
      'Oregano Herbs',
    ],
    'BBQ Chicken Pizza': [
      'Pizza Dough',
      'Pizza Sauce or BBQ Sauce',
      'Mozzarella Cheese',
      'Onions',
      'Capsicum',
      'Smoked BBQ Chicken Pieces',
      'Oregano Herbs',
    ],
  };

  // final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> Submit_button() async {
    String? id = s_id?.uid;
    try {
      if (selectedFlavour == "Chicken Tikka Pizza") {
        // Get all ingredient quantities

        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? spicyChickenTikkaChunks = double.tryParse(
          _quantityControllers["Spicy Chicken Tikka Chunks"]!.text,
        );
        double? greenChilies = double.tryParse(
          _quantityControllers["Green Chilies"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );
        store_Chicken_Tikka_Pizza obj = store_Chicken_Tikka_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          spicyChickenTikkaChunks,
          greenChilies,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          //'supplier_id': s_id?.uid,
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Spicy Chicken Tikka Chunks':
                double.tryParse(
                  _quantityControllers["Spicy Chicken Tikka Chunks"]?.text ??
                      "0",
                ) ??
                0,
            'Green Chilies':
                double.tryParse(
                  _quantityControllers["Green Chilies"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        //ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Fajita Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? fajitaStyleGrilledChicken = double.tryParse(
          _quantityControllers["Fajita_style Grilled Meat"]!.text,
        );
        double? Jalapenos = double.tryParse(
          _quantityControllers["Jalapenos"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );

        store_Fajita_Pizza obj = store_Fajita_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          fajitaStyleGrilledChicken,
          Jalapenos,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Fajita_style Grilled Meat':
                double.tryParse(
                  _quantityControllers["Fajita_style Grilled Meat"]?.text ??
                      "0",
                ) ??
                0,
            'Jalapenos':
                double.tryParse(
                  _quantityControllers["Jalapenos"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          // 'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        // ref.child('Supplier_items').push().set(flavorData);
        // ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Pepperoni Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? beefPepperoniSlices = double.tryParse(
          _quantityControllers["Beef Pepperoni Slices"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );

        Pepperoni_Pizza obj = Pepperoni_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          beefPepperoniSlices,
          oreganoItalianHerbs,
        );
        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Beef Pepperoni Slices':
                double.tryParse(
                  _quantityControllers["Beef Pepperoni Slices"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          // 'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        // String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        // ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Chicken Supreme Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? extraChickenChunks = double.tryParse(
          _quantityControllers["Extra Chicken Chunks"]!.text,
        );
        double? Mushrooms = double.tryParse(
          _quantityControllers["Mushrooms"]!.text,
        );
        double? blackOlive = double.tryParse(
          _quantityControllers["Black Olives"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );
        Chicken_Supreme_Pizza obj = Chicken_Supreme_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          extraChickenChunks,
          Mushrooms,
          blackOlive,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Extra Chicken Chunks':
                double.tryParse(
                  _quantityControllers["Extra Chicken Chunks"]?.text ?? "0",
                ) ??
                0,
            'Mushrooms':
                double.tryParse(
                  _quantityControllers["Mushrooms"]?.text ?? "0",
                ) ??
                0,
            'Black Olives':
                double.tryParse(
                  _quantityControllers["Black Olives"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          //  'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        // ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Afghani Tikka Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]?.text ?? '',
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]?.text ?? '',
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]?.text ?? '',
        );
        double? Onions = double.tryParse(
          _quantityControllers["Onions"]?.text ?? '',
        );
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]?.text ?? '',
        );
        double? creamyAfghaniTikkaChicken = double.tryParse(
          _quantityControllers["Creamy Afghani Tikka Chicken"]?.text ?? '',
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]?.text ?? '',
        );

        Afghani_Tikka_Pizza obj = Afghani_Tikka_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          creamyAfghaniTikkaChicken,
          oreganoItalianHerbs,
        );
        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Creamy Afghani Tikka Chicken':
                double.tryParse(
                  _quantityControllers["Creamy Afghani Tikka Chicken"]?.text ??
                      "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          // 'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        //ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Veggie Lovers Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? Tomatoes = double.tryParse(
          _quantityControllers["Tomatoes"]!.text,
        );
        double? Mushrooms = double.tryParse(
          _quantityControllers["Mushrooms"]!.text,
        );
        double? blackOlive = double.tryParse(
          _quantityControllers["Black Olives"]!.text,
        );
        double? Jalapenos = double.tryParse(
          _quantityControllers["Jalapenos"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );

        Veggie_Lovers_Pizza obj = Veggie_Lovers_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          Mushrooms,
          blackOlive,
          Tomatoes,
          Jalapenos,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Mushrooms':
                double.tryParse(
                  _quantityControllers["Mushrooms"]?.text ?? "0",
                ) ??
                0,
            'Black Olives':
                double.tryParse(
                  _quantityControllers["Black Olives"]?.text ?? "0",
                ) ??
                0,
            'Tomatoes':
                double.tryParse(
                  _quantityControllers["Tomatoes"]?.text ?? "0",
                ) ??
                0,
            'Jalapenos':
                double.tryParse(
                  _quantityControllers["Jalapenos"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          //  'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        // String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        //ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Cheese Lovers Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? cheddarCheese = double.tryParse(
          _quantityControllers["Cheddar Cheese"]!.text,
        );
        double? parmesanCheese = double.tryParse(
          _quantityControllers["Parmesan Cheese"]!.text,
        );
        double? blueCheese = double.tryParse(
          _quantityControllers["Blue Cheese"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );

        Cheese_Lovers_Pizza obj = Cheese_Lovers_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          cheddarCheese,
          parmesanCheese,
          blueCheese,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Cheddar Cheese':
                double.tryParse(
                  _quantityControllers["Cheddar Cheese"]?.text ?? "0",
                ) ??
                0,
            'Parmesan Cheese':
                double.tryParse(
                  _quantityControllers["Parmesan Cheese"]?.text ?? "0",
                ) ??
                0,
            'Blue Cheese':
                double.tryParse(
                  _quantityControllers["Blue Cheese"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          //  'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        //ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Crown Crust Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? chickenNuggetsOrCheesePocketsInCrust = double.tryParse(
          _quantityControllers["Chicken Nuggets or Cheese Pockets"]!.text,
        );
        double? chickenTikkaChunksOrBbqChicken = double.tryParse(
          _quantityControllers["Chicken Tikka Chunks or BBQ Chicken"]!.text,
        );
        double? beefPepperoniSlices = double.tryParse(
          _quantityControllers["Beef Pepperoni Slices"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? Tomatoes = double.tryParse(
          _quantityControllers["Tomatoes"]!.text,
        );
        double? blackOlive = double.tryParse(
          _quantityControllers["Black Olives"]!.text,
        );
        double? Jalapenos = double.tryParse(
          _quantityControllers["Jalapenos"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );

        Crown_Crust_Pizza obj = Crown_Crust_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          chickenNuggetsOrCheesePocketsInCrust,
          chickenTikkaChunksOrBbqChicken,
          beefPepperoniSlices,
          Onions,
          Capsicum,
          blackOlive,
          Tomatoes,
          Jalapenos,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Chicken Nuggets or Cheese Pockets':
                double.tryParse(
                  _quantityControllers["Chicken Nuggets or Cheese Pockets"]
                          ?.text ??
                      "0",
                ) ??
                0,
            'Chicken Tikka Chunks or BBQ Chicken':
                double.tryParse(
                  _quantityControllers["Chicken Tikka Chunks or BBQ Chicken"]
                          ?.text ??
                      "0",
                ) ??
                0,
            'Beef Pepperoni Slices':
                double.tryParse(
                  _quantityControllers["Beef Pepperoni Slices"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Black Olives':
                double.tryParse(
                  _quantityControllers["Black Olives"]?.text ?? "0",
                ) ??
                0,
            'Tomatoes':
                double.tryParse(
                  _quantityControllers["Tomatoes"]?.text ?? "0",
                ) ??
                0,
            'Jalapenos':
                double.tryParse(
                  _quantityControllers["Jalapenos"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          //  'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        // ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Behari Kebab Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaSauce = double.tryParse(
          _quantityControllers["Pizza Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? behariSpicedBeefKebabPieces = double.tryParse(
          _quantityControllers["Behari_Spiced Beef Kebab Pieces"]!.text,
        );
        double? greenChilies = double.tryParse(
          _quantityControllers["Green Chilies"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );
        Behari_Kebab_Pizza obj = Behari_Kebab_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaSauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          behariSpicedBeefKebabPieces,
          greenChilies,
          oreganoItalianHerbs,
        );
        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Behari_Spiced Beef Kebab Pieces':
                double.tryParse(
                  _quantityControllers["Behari_Spiced Beef Kebab Pieces"]
                          ?.text ??
                      "0",
                ) ??
                0,
            'Green Chilies':
                double.tryParse(
                  _quantityControllers["Green Chilies"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          //  'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        // ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "Creamy Super Max Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? whiteOrCreamySauce = double.tryParse(
          _quantityControllers["White_Creamy Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onions = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? chickenChunks = double.tryParse(
          _quantityControllers["Chicken Chunks"]!.text,
        );
        double? sweetCorn = double.tryParse(
          _quantityControllers["Sweet Corn"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );
        Behari_Kebab_Pizza obj = Behari_Kebab_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          whiteOrCreamySauce,
          mozzarellaCheese,
          Onions,
          Capsicum,
          chickenChunks,
          sweetCorn,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'White_Creamy Sauce':
                double.tryParse(
                  _quantityControllers["White_Creamy Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Chicken Chunks':
                double.tryParse(
                  _quantityControllers["Chicken Chunks"]?.text ?? "0",
                ) ??
                0,
            'Sweet Corn':
                double.tryParse(
                  _quantityControllers["Sweet Corn"]?.text ?? "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          // 'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        //ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      } else if (selectedFlavour == "BBQ Chicken Pizza") {
        double? pizzaDough = double.tryParse(
          _quantityControllers["Pizza Dough"]!.text,
        );
        double? pizzaOrBbqSauce = double.tryParse(
          _quantityControllers["Pizza Sauce or BBQ Sauce"]!.text,
        );
        double? mozzarellaCheese = double.tryParse(
          _quantityControllers["Mozzarella Cheese"]!.text,
        );
        double? Onion = double.tryParse(_quantityControllers["Onions"]!.text);
        double? Capsicum = double.tryParse(
          _quantityControllers["Capsicum"]!.text,
        );
        double? smokedBbqChickenPieces = double.tryParse(
          _quantityControllers["Smoked BBQ Chicken Pieces"]!.text,
        );
        double? oreganoItalianHerbs = double.tryParse(
          _quantityControllers["Oregano Herbs"]!.text,
        );
        BBQ_Chicken_Pizza obj = BBQ_Chicken_Pizza();
        double? totalCalories = obj.calculate_calories(
          pizzaDough,
          pizzaOrBbqSauce,
          mozzarellaCheese,
          Onion,
          Capsicum,
          smokedBbqChickenPieces,
          oreganoItalianHerbs,
        );

        Map<String, dynamic> flavorData = {
          'Flavour': selectedFlavour,
          'ingredients': {
            'Pizza Dough':
                double.tryParse(
                  _quantityControllers["Pizza Dough"]?.text ?? "0",
                ) ??
                0,
            'Pizza Sauce or BBQ Sauce':
                double.tryParse(
                  _quantityControllers["Pizza Sauce or BBQ Sauce"]?.text ?? "0",
                ) ??
                0,
            'Mozzarella Cheese':
                double.tryParse(
                  _quantityControllers["Mozzarella Cheese"]?.text ?? "0",
                ) ??
                0,
            'Onions':
                double.tryParse(_quantityControllers["Onions"]?.text ?? "0") ??
                0,
            'Capsicum':
                double.tryParse(
                  _quantityControllers["Capsicum"]?.text ?? "0",
                ) ??
                0,
            'Smoked BBQ Chicken Pieces':
                double.tryParse(
                  _quantityControllers["Smoked BBQ Chicken Pieces"]?.text ??
                      "0",
                ) ??
                0,
            'Oregano Herbs':
                double.tryParse(
                  _quantityControllers["Oregano Herbs"]?.text ?? "0",
                ) ??
                0,
          },
          // 'supplier_id': s_id?.uid,
          'supplier_name': _nameController.text,
          'timestamp': ServerValue.timestamp,
          'Calories': totalCalories,
        };
        //String? id = s_id?.uid;
        //ref.child('Supplier_items').push().set(flavorData);
        //ref.child('Supplier_items').child(id.toString()).push().set(flavorData);
        ref.child(id.toString()).child('Supplier_items').push().set(flavorData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pizza flavor added successfully!')),
        );
      }
      // Add similar blocks for other pizza types
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error adding pizza flavor: $e')));
    }
  }
  // Submit_button() async {
  //   if (selectedSize == "" && selectedFlavour == "") {
  //     log("Enter the Required Fields");
  //   }
  //   else{
  //     FirebaseFirestore.instance.collection(_idController.toString()).doc("selectedFlavour").set(flavorData)
  //   }
  // }

  Map<String, bool> selectedToppings = {};

  @override
  void dispose() {
    _idController.dispose();
    _nameController.dispose();
    _otherToppingController.dispose();
    for (var controller in _quantityControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  void _onFlavourChanged(String? flavour) {
    setState(() {
      selectedFlavour = flavour;
      selectedToppings = {
        for (var t in (flavourToppings[flavour] ?? [])) t: false,
      };
      // Clean up old controllers
      for (var controller in _quantityControllers.values) {
        controller.dispose();
      }
      _quantityControllers.clear();
      for (var t in (flavourToppings[flavour] ?? [])) {
        _quantityControllers[t] = TextEditingController();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bite Buddy', style: TextStyle(color: Colors.red)),
        backgroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ID
              const Text('Shop Name:', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              TextField(
                controller: _idController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Enter your Shop Name',
                  hintStyle: TextStyle(color: Colors.white),
                ),
                style: const TextStyle(fontSize: 14, color: Colors.white),
              ),
              const SizedBox(height: 16),

              // Name
              const Text('Name:', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Enter your name',
                  hintStyle: TextStyle(color: Colors.white),
                ),
                style: TextStyle(fontSize: 14, color: Colors.white),
              ),
              const SizedBox(height: 16),

              // Size Dropdown
              const Text('Size:', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: selectedSize,
                items:
                    pizzaSizes
                        .map(
                          (size) =>
                              DropdownMenuItem(value: size, child: Text(size)),
                        )
                        .toList(),
                onChanged: (value) {
                  setState(() {
                    selectedSize = value;
                  });
                },
                decoration: const InputDecoration(border: OutlineInputBorder()),
                selectedItemBuilder: (BuildContext context) {
                  return pizzaSizes.map((size) {
                    return Text(
                      size,
                      style: const TextStyle(
                        color: Colors.white,
                      ), // White color for selected item
                    );
                  }).toList();
                },
              ),
              const SizedBox(height: 16),

              // Flavour Dropdown
              const Text('Flavour:', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: selectedFlavour,

                items:
                    pizzaFlavours
                        .map(
                          (flavour) => DropdownMenuItem(
                            value: flavour,

                            child: Text(flavour),
                          ),
                        )
                        .toList(),
                onChanged: _onFlavourChanged,
                decoration: const InputDecoration(border: OutlineInputBorder()),
                selectedItemBuilder: (BuildContext context) {
                  return pizzaFlavours.map((flavour) {
                    return Text(
                      flavour,
                      style: const TextStyle(
                        color: Colors.white,
                      ), // White text for selected item
                    );
                  }).toList();
                },
              ),
              const SizedBox(height: 16),

              // Toppings (dynamic based on flavour)
              if (selectedFlavour != null)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Toppings:',
                      style: TextStyle(color: Colors.red),
                    ),
                    const SizedBox(height: 8),
                    ...selectedToppings.keys.map(
                      (topping) => Row(
                        children: [
                          Checkbox(
                            value: selectedToppings[topping],
                            onChanged: (val) {
                              setState(() {
                                selectedToppings[topping] = val ?? false;
                              });
                            },
                          ),
                          Text(
                            topping,
                            style: const TextStyle(color: Colors.white),
                          ),
                          const SizedBox(width: 8),
                          if (selectedToppings[topping] == true)
                            Expanded(
                              child: TextField(
                                controller: _quantityControllers[topping],
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  hintText: 'Enter quantity in grams',
                                  hintStyle: TextStyle(color: Colors.grey),
                                  border: OutlineInputBorder(),
                                ),
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),

              // Other Button and TextBox
              const Text('Other:', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _showOtherTextBox = !_showOtherTextBox;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFDD050D), // Red background
                ),
                child: const Text('Other'),
              ),
              if (_showOtherTextBox) ...[
                const SizedBox(height: 8),
                const Text('Specify:', style: TextStyle(color: Colors.red)),
                const SizedBox(height: 8),
                TextField(
                  controller: _otherToppingController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Enter other topping',
                    hintStyle: TextStyle(color: Colors.white),
                  ),
                  style: const TextStyle(fontSize: 14), // Reduce text size
                ),
              ],
              const SizedBox(height: 16),

              // Picture Box and Button
              const Text('Picture:', style: TextStyle(color: Colors.red)),
              const SizedBox(height: 8),
              Row(
                children: [
                  ElevatedButton(
                    onPressed: () {
                      // Handle image selection
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(
                        0xFFDD050D,
                      ), // Red background
                    ),
                    child: const Text('Select Image'),
                  ),
                  const SizedBox(width: 10),
                  // Placeholder for image display
                  Container(
                    width: 50,
                    height: 50,
                    color: Colors.grey, // Placeholder color
                    child: const Center(child: Text('Image')),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Submit Button
              ElevatedButton(
                onPressed: Submit_button,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFDD050D),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Submit', style: TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
      backgroundColor: const Color(0xFF000000), // Set background color to black
    );
  }
}
