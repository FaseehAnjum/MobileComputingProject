import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFF6200EE);
const Color kPrimaryLightColor = Color(0xFFBB86FC);
const double kDefaultPadding = 16.0;
