import 'package:flutter/material.dart';
import 'supplier_add.dart'; // Import the SupplierAdd page
import 'Supplier_view_item.dart';

class SupplierScreen extends StatelessWidget {
  const SupplierScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF000000), // Black background
      appBar: AppBar(
        title: const Text(
          'Supplier Dashboard',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Logo
            ClipOval(
              child: Image.asset(
                'assets/images/logor.jpg', // Replace with your logo path
                width:
                    MediaQuery.of(context).size.width *
                    0.2, // Adjust size as needed
                height:
                    MediaQuery.of(context).size.width * 0.2, // Ensure circle
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 30),

            // Grid of cards
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 16.0,
                crossAxisSpacing: 16.0,
                children: [
                  _buildCard(
                    context,
                    'Add Food Item',
                    'assets/images/image1.jpeg',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SupplierAdd(),
                        ),
                      );
                    },
                  ),
                  _buildCard(
                    context,
                    'Update Food Item',
                    'assets/images/image2.jpeg',
                    () {
                      // Handle update action
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Update Food Item pressed'),
                        ),
                      );
                    }, //SupplierViewItem
                  ),
                  _buildCard(
                    context,
                    'Delete Food Item',
                    'assets/images/image3.jpeg',
                    () {
                      // Handle delete action
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Delete Food Item pressed'),
                        ),
                      );
                    },
                  ),
                  _buildCard(
                    context,
                    'View Food Items',
                    'assets/images/image4.jpeg',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SupplierViewItem(),
                        ),
                      );
                      // Handle view action
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(
    BuildContext context,
    String title,
    String imagePath,
    VoidCallback onPressed,
  ) {
    return Card(
      elevation: 8.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      child: InkWell(
        onTap: onPressed,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              flex: 3,
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(15.0),
                ),
                child: Image.asset(imagePath, fit: BoxFit.cover),
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                decoration: const BoxDecoration(
                  color: Color(0xFFDD050D),
                  borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(15.0),
                  ),
                ),
                child: Center(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
